#include "CapteurTemperature.h"
#include <math.h>

CapteurTemperature::CapteurTemperature(){
}

CapteurTemperature::~CapteurTemperature(){
}


void CapteurTemperature::actualiserValeur(){
	valeurLue = analogRead(numBroche);
}

void CapteurTemperature::setNumBroche(int num){
	numBroche = num;
}

int CapteurTemperature::getValeurLue(){
	actualiserValeur();
	return valeurLue;
}

float CapteurTemperature::getTemperatureDegre(){

	actualiserValeur();
    
    float R = 1023.0/valeurLue-1.0;
    R = R0*R;

    float temperature = 1.0/(log(R/R0)/B+1/298.15)-273.15;
    
    return temperature;
}

#ifndef _CapteurTemperature
#define _CapteurTemperature

#if ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif

class CapteurTemperature{
	private:
		int valeurLue;
		const int B = 4275;
		const int R0 = 100000;
		int numBroche;
		
		void actualiserValeur();
		
	public:
		CapteurTemperature();
		~CapteurTemperature();
		void setNumBroche(int num);
		int getValeurLue();
		float getTemperatureDegre();
};

#endif
